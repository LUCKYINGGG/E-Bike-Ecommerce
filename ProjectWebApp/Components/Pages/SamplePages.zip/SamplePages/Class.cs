﻿namespace hogwildweb.Components.SamplePages
{
    public class Class
    {
    }
}
